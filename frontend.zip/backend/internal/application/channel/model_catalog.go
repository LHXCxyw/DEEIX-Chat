package channel

import (
	"encoding/json"
	"strings"

	"github.com/DEEIX-AI/DEEIX-Chat/backend/internal/ports/llm"
)

const (
	// TaskTypeChat 表示普通聊天或内部文本任务。
	TaskTypeChat = "chat"
	// TaskTypeImageGeneration 表示图片生成任务。
	TaskTypeImageGeneration = "image_generation"
	// TaskTypeImageEdit 表示图片编辑任务。
	TaskTypeImageEdit = "image_edit"
	// TaskTypeVideoGeneration 表示视频生成任务。
	TaskTypeVideoGeneration = "video_generation"
	// TaskTypeVideoExtension 表示基于源视频的扩展任务。
	TaskTypeVideoExtension = "video_extension"

	modelKindChat           = "chat"
	modelKindAudio          = "audio"
	modelKindImageGen       = "image_gen"
	modelKindImageEdit      = "image_edit"
	modelKindVideoGen       = "video_gen"
	modelKindVideoExtension = "video_extension"

	compatibleOpenAI     = "openai"
	compatibleAnthropic  = "anthropic"
	compatibleGoogle     = "google"
	compatibleXAI        = "xai"
	compatibleOpenRouter = "openrouter"
	compatibleCustom     = "custom"

	protocolOpenAIImageGenerations = llm.AdapterOpenAIImageGenerations
	protocolOpenAIImageEdits       = llm.AdapterOpenAIImageEdits
	protocolOpenAIVideoGenerations = "openai_video_generations"
	protocolImageEditsJSON    = llm.AdapterImageEditsJSON
	protocolGoogleImageGeneration  = llm.AdapterGoogleImageGeneration
	protocolGeminiInteractions     = llm.AdapterGeminiInteractions
	protocolXAIImage               = llm.AdapterXAIImage
	protocolXAIImageEdits          = llm.AdapterXAIImageEdits
	protocolXAIVideo               = llm.AdapterXAIVideo
	protocolXAIVideoExtensions     = llm.AdapterXAIVideoExtensions
)

var protocolDefaultKindOrder = []string{
	modelKindChat,
	modelKindAudio,
	modelKindImageGen,
	modelKindImageEdit,
	modelKindVideoGen,
	modelKindVideoExtension,
}

func normalizeCompatible(raw string) string {
	switch strings.TrimSpace(strings.ToLower(raw)) {
	case compatibleAnthropic:
		return compatibleAnthropic
	case compatibleGoogle:
		return compatibleGoogle
	case compatibleXAI:
		return compatibleXAI
	case compatibleOpenRouter:
		return compatibleOpenRouter
	case compatibleCustom:
		return compatibleCustom
	case "", compatibleOpenAI:
		return compatibleOpenAI
	default:
		return ""
	}
}

func protocolDefaultsForCompatible(compatible string) string {
	defaults := map[string]string{}
	for kind, protocol := range systemFallbackProtocols(normalizeCompatible(compatible)) {
		defaults[kind] = protocol
	}
	payload, _ := json.Marshal(defaults)
	return string(payload)
}

func normalizeProtocolDefaultsJSON(raw string) (string, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return `{}`, nil
	}
	var payload map[string]*string
	if err := json.Unmarshal([]byte(raw), &payload); err != nil || payload == nil {
		return "", ErrInvalidJSONConfig
	}

	defaults := make(map[string]string)
	for _, kind := range protocolDefaultKindOrder {
		value, ok := payload[kind]
		if !ok || value == nil {
			continue
		}
		protocol := strings.TrimSpace(strings.ToLower(*value))
		if protocol == "" {
			continue
		}
		if !isKnownProtocol(protocol) {
			return "", ErrInvalidAdapter
		}
		if !isProtocolAllowedForKind(kind, protocol) {
			return "", ErrInvalidAdapter
		}
		defaults[kind] = protocol
	}

	normalized, _ := json.Marshal(defaults)
	return string(normalized), nil
}

func systemFallbackProtocols(compatible string) map[string]string {
	switch normalizeCompatible(compatible) {
	case compatibleOpenAI:
		return map[string]string{
			modelKindChat:      llm.AdapterOpenAIChatCompletions,
			modelKindAudio:     llm.AdapterOpenAIChatCompletions,
			modelKindImageGen:  protocolOpenAIImageGenerations,
			modelKindImageEdit: protocolOpenAIImageEdits,
			modelKindVideoGen:  protocolOpenAIVideoGenerations,
		}
	case compatibleAnthropic:
		return map[string]string{
			modelKindChat:  llm.AdapterAnthropicMessages,
			modelKindAudio: llm.AdapterAnthropicMessages,
		}
	case compatibleGoogle:
		return map[string]string{
			modelKindChat:      llm.AdapterGoogleGenerateContent,
			modelKindAudio:     llm.AdapterGoogleGenerateContent,
			modelKindImageGen:  protocolGoogleImageGeneration,
			modelKindImageEdit: protocolGoogleImageGeneration,
			modelKindVideoGen:  protocolGeminiInteractions,
		}
	case compatibleXAI:
		return map[string]string{
			modelKindChat:           llm.AdapterXAIResponses,
			modelKindAudio:          llm.AdapterXAIResponses,
			modelKindImageGen:       protocolXAIImage,
			modelKindImageEdit:      protocolXAIImageEdits,
			modelKindVideoGen:       protocolXAIVideo,
			modelKindVideoExtension: protocolXAIVideoExtensions,
		}
	case compatibleOpenRouter:
		return map[string]string{
			modelKindChat:      llm.AdapterOpenRouterResponses,
			modelKindAudio:     llm.AdapterOpenRouterResponses,
			modelKindImageGen:  protocolOpenAIImageGenerations,
			modelKindImageEdit: protocolOpenAIImageEdits,
			modelKindVideoGen:  protocolOpenAIVideoGenerations,
		}
	case compatibleCustom:
		return map[string]string{
			modelKindChat:      llm.AdapterOpenAIChatCompletions,
			modelKindAudio:     llm.AdapterOpenAIChatCompletions,
			modelKindImageGen:  protocolOpenAIImageGenerations,
			modelKindImageEdit: protocolOpenAIImageEdits,
		}
	default:
		return map[string]string{}
	}
}

func isKnownProtocol(raw string) bool {
	switch strings.TrimSpace(strings.ToLower(raw)) {
	case llm.AdapterOpenAIResponses,
		llm.AdapterOpenRouterChat,
		llm.AdapterOpenRouterResponses,
		llm.AdapterOpenAIChatCompletions,
		llm.AdapterAnthropicMessages,
		llm.AdapterGoogleGenerateContent,
		llm.AdapterXAIResponses,
		protocolOpenAIImageGenerations,
		protocolOpenAIImageEdits,
		protocolOpenAIVideoGenerations,
		protocolImageEditsJSON,
		protocolGoogleImageGeneration,
		protocolGeminiInteractions,
		protocolXAIImage,
		protocolXAIImageEdits,
		protocolXAIVideo,
		protocolXAIVideoExtensions:
		return true
	default:
		return false
	}
}

func resolveRouteProtocol(explicit string, upCompatible string, defaultsJSON string, kindsJSON string) (string, error) {
	kind := primaryKindFromKinds(kindsJSON)
	if protocol := strings.TrimSpace(strings.ToLower(explicit)); protocol != "" {
		if !isKnownProtocol(protocol) {
			return "", ErrInvalidAdapter
		}
		if !isProtocolAllowedForKinds(kindsJSON, protocol) {
			return "", ErrInvalidAdapter
		}
		return protocol, nil
	}

	if kind == "" {
		return "", ErrProtocolRequired
	}
	if protocol := unifiedProtocolForMultiKindRoute(upCompatible, defaultsJSON, kindsJSON); protocol != "" {
		return protocol, nil
	}
	if protocol := protocolDefaultForKind(defaultsJSON, kind); protocol != "" {
		return protocol, nil
	}
	if protocol := systemFallbackProtocols(upCompatible)[kind]; protocol != "" {
		return protocol, nil
	}
	return "", ErrProtocolRequired
}

// resolveRouteProtocols 解析批量导入时的协议列表，并为同一媒体模型补齐配套协议绑定。
func resolveRouteProtocols(explicit []string, upCompatible string, defaultsJSON string, kindsJSON string) ([]string, error) {
	protocols := make([]string, 0, len(explicit))
	seen := make(map[string]struct{}, len(explicit))
	for _, raw := range explicit {
		value := strings.TrimSpace(strings.ToLower(raw))
		if value == "" {
			continue
		}
		protocol, err := resolveRouteProtocol(value, upCompatible, defaultsJSON, kindsJSON)
		if err != nil {
			return nil, err
		}
		if _, ok := seen[protocol]; ok {
			continue
		}
		seen[protocol] = struct{}{}
		protocols = append(protocols, protocol)
	}
	if len(protocols) > 0 {
		if !isSupportedRouteProtocolCombination(protocols) {
			return nil, ErrInvalidRouteProtocolCombination
		}
		return protocols, nil
	}

	kinds := parseKinds(kindsJSON)
	if protocol := unifiedProtocolForMultiKindRoute(upCompatible, defaultsJSON, kindsJSON); protocol != "" {
		return []string{protocol}, nil
	}
	if hasModelKind(kinds, modelKindImageGen) && hasModelKind(kinds, modelKindImageEdit) {
		generationProtocol := defaultRouteProtocolForKind(upCompatible, defaultsJSON, modelKindImageGen)
		editProtocol := defaultRouteProtocolForKind(upCompatible, defaultsJSON, modelKindImageEdit)
		if generationProtocol != "" && editProtocol != "" {
			protocols = uniqueRouteProtocols(generationProtocol, editProtocol)
			if isSupportedRouteProtocolCombination(protocols) {
				return protocols, nil
			}
		}
	}
	if hasModelKind(kinds, modelKindVideoGen) && hasModelKind(kinds, modelKindVideoExtension) && normalizeCompatible(upCompatible) == compatibleXAI {
		generationProtocol := defaultRouteProtocolForKind(upCompatible, defaultsJSON, modelKindVideoGen)
		if generationProtocol == protocolXAIVideo {
			return []string{protocolXAIVideo, protocolXAIVideoExtensions}, nil
		}
	}

	protocol, err := resolveRouteProtocol("", upCompatible, defaultsJSON, kindsJSON)
	if err != nil {
		return nil, err
	}
	return []string{protocol}, nil
}

func unifiedProtocolForMultiKindRoute(upCompatible string, defaultsJSON string, kindsJSON string) string {
	kinds := parseKinds(kindsJSON)
	if len(kinds) <= 1 || !hasModelKind(kinds, modelKindVideoGen) {
		return ""
	}
	protocol := defaultRouteProtocolForKind(upCompatible, defaultsJSON, modelKindVideoGen)
	if protocol == "" || !routeProtocolSupportsAllKinds(protocol, kinds) {
		return ""
	}
	return protocol
}

func routeProtocolSupportsAllKinds(protocol string, kinds []string) bool {
	for _, kind := range kinds {
		if !isProtocolAllowedForKind(kind, protocol) {
			return false
		}
	}
	return len(kinds) > 0
}

// uniqueRouteProtocols 保留协议声明顺序，同时避免 Google 图片这类同协议双能力模型创建重复绑定。
func uniqueRouteProtocols(values ...string) []string {
	protocols := make([]string, 0, len(values))
	seen := make(map[string]struct{}, len(values))
	for _, raw := range values {
		protocol := strings.TrimSpace(strings.ToLower(raw))
		if protocol == "" {
			continue
		}
		if _, ok := seen[protocol]; ok {
			continue
		}
		seen[protocol] = struct{}{}
		protocols = append(protocols, protocol)
	}
	return protocols
}

// defaultRouteProtocolForKind 优先使用上游配置的类型默认协议，其次回退到兼容类型内置协议。
func defaultRouteProtocolForKind(upCompatible string, defaultsJSON string, kind string) string {
	if protocol := protocolDefaultForKind(defaultsJSON, kind); protocol != "" {
		return protocol
	}
	return systemFallbackProtocols(upCompatible)[kind]
}

func isProtocolAllowedForKinds(kindsJSON string, protocol string) bool {
	kinds := parseKinds(kindsJSON)
	if len(kinds) == 0 {
		return true
	}
	for _, kind := range kinds {
		if isProtocolAllowedForKind(kind, protocol) {
			return true
		}
	}
	return false
}

// isSupportedRouteProtocolCombination 限制同一绑定 pair 只能单协议，或同一媒体模型的配套协议。
func isSupportedRouteProtocolCombination(protocols []string) bool {
	seen := make(map[string]struct{}, len(protocols))
	for _, raw := range protocols {
		protocol := strings.TrimSpace(strings.ToLower(raw))
		if protocol == "" {
			continue
		}
		seen[protocol] = struct{}{}
	}
	if len(seen) <= 1 {
		return true
	}
	if len(seen) != 2 {
		return false
	}
	_, hasGeneration := seen[protocolOpenAIImageGenerations]
	_, hasEdit := seen[protocolOpenAIImageEdits]
	if hasGeneration && hasEdit {
		return true
	}
	// JSON 编辑协议与 OpenAI 兼容生成协议配套：生成走 generations，编辑走 JSON 版 edits。
	_, hasJSONEdit := seen[protocolImageEditsJSON]
	if hasGeneration && hasJSONEdit {
		return true
	}
	_, hasGeneration = seen[protocolXAIImage]
	_, hasEdit = seen[protocolXAIImageEdits]
	if hasGeneration && hasEdit {
		return true
	}
	_, hasVideoGeneration := seen[protocolXAIVideo]
	_, hasVideoExtension := seen[protocolXAIVideoExtensions]
	return hasVideoGeneration && hasVideoExtension
}

func protocolDefaultForKind(defaultsJSON string, kind string) string {
	defaults := make(map[string]*string)
	if err := json.Unmarshal([]byte(strings.TrimSpace(defaultsJSON)), &defaults); err != nil {
		return ""
	}
	value, ok := defaults[kind]
	if !ok || value == nil {
		return ""
	}
	protocol := strings.TrimSpace(strings.ToLower(*value))
	if !isKnownProtocol(protocol) {
		return ""
	}
	if !isProtocolAllowedForKind(kind, protocol) {
		return ""
	}
	return protocol
}

func isProtocolAllowedForKind(kind string, protocol string) bool {
	switch kind {
	case modelKindChat:
		switch protocol {
		case llm.AdapterOpenAIResponses,
			llm.AdapterOpenRouterChat,
			llm.AdapterOpenRouterResponses,
			llm.AdapterOpenAIChatCompletions,
			llm.AdapterAnthropicMessages,
			llm.AdapterGoogleGenerateContent,
			protocolGeminiInteractions,
			llm.AdapterXAIResponses:
			return true
		default:
			return false
		}
	case modelKindAudio:
		switch protocol {
		case llm.AdapterOpenAIResponses,
			llm.AdapterOpenRouterChat,
			llm.AdapterOpenRouterResponses,
			llm.AdapterOpenAIChatCompletions,
			llm.AdapterAnthropicMessages,
			llm.AdapterGoogleGenerateContent,
			llm.AdapterXAIResponses:
			return true
		default:
			return false
		}
	case modelKindImageGen:
		switch protocol {
		case protocolOpenAIImageGenerations,
			protocolGoogleImageGeneration,
			protocolGeminiInteractions,
			protocolXAIImage:
			return true
		default:
			return false
		}
	case modelKindImageEdit:
		switch protocol {
		case protocolOpenAIImageEdits,
			// generations 协议适配器可按任务切换到 edits 端点执行编辑请求，
			// 因此模型标注 image_edit 能力时允许绑定在 generations 协议上。
			protocolOpenAIImageGenerations,
			protocolGoogleImageGeneration,
			protocolGeminiInteractions,
			protocolXAIImageEdits,
			// image_edits_json：编辑端点路径与 OpenAI 相同但请求为 JSON 体，需要独立协议。
			protocolImageEditsJSON:
			return true
		default:
			return false
		}
	case modelKindVideoGen:
		switch protocol {
		case protocolOpenAIVideoGenerations,
			protocolGeminiInteractions,
			protocolXAIVideo:
			return true
		default:
			return false
		}
	case modelKindVideoExtension:
		return protocol == protocolXAIVideoExtensions
	default:
		return false
	}
}

// NormalizeTaskType 归一化模型路由任务类型。
// 未传任务类型时按聊天处理，保留旧调用方的默认行为。
func NormalizeTaskType(raw string) string {
	switch strings.TrimSpace(strings.ToLower(raw)) {
	case TaskTypeImageGeneration:
		return TaskTypeImageGeneration
	case TaskTypeImageEdit:
		return TaskTypeImageEdit
	case TaskTypeVideoGeneration:
		return TaskTypeVideoGeneration
	case TaskTypeVideoExtension:
		return TaskTypeVideoExtension
	default:
		return TaskTypeChat
	}
}

// IsRouteAllowedForTask 判断指定模型 kind 与协议是否可服务当前任务。
// 聊天任务允许任意已实现适配器协议；图片与视频任务必须命中对应 kind 和协议。
func IsRouteAllowedForTask(taskType string, kindsJSON string, protocol string) bool {
	taskType = NormalizeTaskType(taskType)
	protocol = strings.TrimSpace(strings.ToLower(protocol))
	if taskType == TaskTypeChat {
		return isKnownProtocol(protocol)
	}

	kinds := parseKinds(kindsJSON)
	if len(kinds) == 0 {
		switch taskType {
		case TaskTypeImageGeneration:
			return isProtocolAllowedForKind(modelKindImageGen, protocol)
		case TaskTypeImageEdit:
			return isProtocolAllowedForKind(modelKindImageEdit, protocol)
		case TaskTypeVideoGeneration:
			return isProtocolAllowedForKind(modelKindVideoGen, protocol) && protocol != protocolXAIVideoExtensions
		case TaskTypeVideoExtension:
			return isProtocolAllowedForKind(modelKindVideoExtension, protocol)
		default:
			return false
		}
	}
	switch taskType {
	case TaskTypeImageGeneration:
		return hasModelKind(kinds, modelKindImageGen) && isProtocolAllowedForKind(modelKindImageGen, protocol)
	case TaskTypeImageEdit:
		return hasModelKind(kinds, modelKindImageEdit) && isProtocolAllowedForKind(modelKindImageEdit, protocol)
	case TaskTypeVideoGeneration:
		return hasModelKind(kinds, modelKindVideoGen) && isProtocolAllowedForKind(modelKindVideoGen, protocol) && protocol != protocolXAIVideoExtensions
	case TaskTypeVideoExtension:
		return hasModelKind(kinds, modelKindVideoExtension) && isProtocolAllowedForKind(modelKindVideoExtension, protocol)
	default:
		return false
	}
}

// hasModelKind 判断模型 kind 列表是否包含目标能力。
func hasModelKind(kinds []string, target string) bool {
	for _, kind := range kinds {
		if kind == target {
			return true
		}
	}
	return false
}

func primaryKindFromKinds(kindsJSON string) string {
	kinds := parseKinds(kindsJSON)
	for _, candidate := range protocolDefaultKindOrder {
		for _, kind := range kinds {
			if kind == candidate {
				return kind
			}
		}
	}
	return ""
}

func inferKindsJSON(platformModelName string) string {
	code := strings.ToLower(strings.TrimSpace(platformModelName))
	switch {
	case isGeminiOmniInteractionsModel(code):
		return `["chat","image_gen","image_edit","video_gen"]`
	case strings.HasPrefix(code, "gpt-image-"), code == "chatgpt-image-latest", code == "dall-e-2",
		isGeminiImageGenerationModel(code), isXAIImageGenerationModel(code):
		return `["image_gen","image_edit"]`
	case code == "dall-e-3", strings.HasPrefix(code, "imagen-"):
		return `["image_gen"]`
	case isXAIVideoGenerationModel(code):
		return `["video_gen","video_extension"]`
	case code == "sora", code == "veo-2", strings.HasPrefix(code, "kling"), strings.HasPrefix(code, "veo-"):
		return `["video_gen"]`
	case strings.HasPrefix(code, "gpt-4o-audio"):
		return `["audio"]`
	case strings.HasPrefix(code, "claude-3"), strings.HasPrefix(code, "claude-2"),
		strings.HasPrefix(code, "gpt-4o"), strings.HasPrefix(code, "gpt-4-turbo"),
		strings.HasPrefix(code, "gemini-1.5"), strings.HasPrefix(code, "gemini-2.5"),
		code == "grok-3", code == "grok-2":
		return `["chat"]`
	default:
		return `["chat"]`
	}
}

func isGeminiOmniInteractionsModel(code string) bool {
	return strings.HasPrefix(strings.TrimSpace(strings.ToLower(code)), "gemini-omni-flash")
}

func isGeminiImageGenerationModel(code string) bool {
	switch strings.TrimSpace(strings.ToLower(code)) {
	case "nano-banana", "nano-banana-2", "nano-banana-pro",
		"gemini-2.5-flash-image",
		"gemini-3.1-flash-image",
		"gemini-3-pro-image",
		"gemini-3.1-flash-image-preview",
		"gemini-3-pro-image-preview":
		return true
	default:
		return false
	}
}

func isXAIImageGenerationModel(code string) bool {
	return strings.HasPrefix(strings.TrimSpace(strings.ToLower(code)), "grok-imagine-image")
}

func isXAIVideoGenerationModel(code string) bool {
	return strings.HasPrefix(strings.TrimSpace(strings.ToLower(code)), "grok-imagine-video")
}
