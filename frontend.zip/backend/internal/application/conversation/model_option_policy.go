package conversation

import (
	"encoding/json"
	"github.com/DEEIX-AI/DEEIX-Chat/backend/internal/pkg/textutil"
	"strings"

	"github.com/DEEIX-AI/DEEIX-Chat/backend/internal/ports/llm"
	"github.com/DEEIX-AI/DEEIX-Chat/backend/internal/shared/nativetool"
)

const (
	modelOptionPolicyAllowlist = "allowlist"
	modelOptionPolicyDenylist  = "denylist"
	modelOptionPolicyDisabled  = "disabled"
)

var hardDeniedModelOptionPaths = [][]string{
	{"model"},
	{"messages"},
	{"input"},
	{"instructions"},
	{"prompt"},
	{"system"},
	{"systemInstruction"},
	{"headers"},
	{"api_key"},
	{"apiKey"},
	{"base_url"},
	{"baseURL"},
	{"stream"},
	{"previous_response_id"},
	{"prompt_cache_key"},
	{"prompt_cache_options"},
	{"prompt_cache_breakpoint"},
	{"prompt_cache_retention"},
}

type modelOptionPolicyConfig struct {
	Mode                  string
	AllowedPathsJSON      string
	DeniedPathsJSON       string
	ModelCapabilitiesJSON string
}

// mediaOptionBaselinePaths 媒体生成协议的产品化参数兜底白名单。
// 这些路径是画布/对话 UI 实际暴露的媒体控件，发送后仍会被协议级 sanitize 收敛；
// 管理员白名单无论是否包含对应协议段（如旧版本初始化的配置缺少视频段），都保证放行，
// 避免媒体参数被整体丢弃后静默回退到产品默认值。
var mediaOptionBaselinePaths = map[string][]string{
	"openai_image_generations": {"background", "n", "output_compression", "output_format", "partial_images", "quality", "response_format", "size"},
	"openai_image_edits":       {"background", "input_fidelity", "n", "output_compression", "output_format", "partial_images", "quality", "response_format", "size"},
	"xai_image":                {"aspect_ratio", "n", "resolution", "response_format"},
	"xai_image_edits":          {"aspect_ratio", "n", "resolution", "response_format"},
	"google_image_generation":  {"generationConfig.responseModalities", "generationConfig.imageConfig.aspectRatio", "generationConfig.imageConfig.imageSize"},
	"gemini_interactions": {
		"generation_config.temperature",
		"generation_config.top_p",
		"generation_config.max_output_tokens",
		"response_format.type",
		"response_format.aspect_ratio",
		"response_format.image_size",
		"response_format.mime_type",
		"response_format.schema",
		"generation_config.video_config.task",
		"generation_config.video_config.duration_seconds",
	},
	"xai_video":                {"aspect_ratio", "duration", "resolution"},
	"xai_video_extensions":     {"duration"},
	"openai_video_generations": {"aspect_ratio", "duration", "resolution", "seconds", "size"},
}

// mediaOptionBaselinePathsFor 返回指定协议的产品化媒体参数兜底路径。
func mediaOptionBaselinePathsFor(protocolKey string) [][]string {
	raw, ok := mediaOptionBaselinePaths[protocolKey]
	if !ok {
		return nil
	}
	paths := make([][]string, 0, len(raw))
	for _, value := range raw {
		if path := splitModelOptionPath(value); len(path) > 0 {
			paths = append(paths, path)
		}
	}
	return paths
}

func filterModelOptions(options map[string]any, protocol string, cfg modelOptionPolicyConfig) map[string]any {
	mode := strings.TrimSpace(cfg.Mode)
	if mode == "" {
		mode = modelOptionPolicyAllowlist
	}
	if mode == modelOptionPolicyDisabled {
		return nil
	}

	protocolKey := modelOptionPolicyProtocolKey(protocol)
	defaultOptions := modelCapabilityDefaultOptions(cfg.ModelCapabilitiesJSON)
	policyOptions := mergeModelOptionDefaults(
		defaultOptions,
		options,
		modelCapabilityLockedOptionPaths(cfg.ModelCapabilitiesJSON),
	)
	if len(policyOptions) == 0 {
		return nil
	}
	nativeTools := nativeProviderToolsFromOption(protocolKey, policyOptions["tools"], cfg.ModelCapabilitiesJSON)
	delete(policyOptions, "tools")
	denied := append([][]string{}, hardDeniedModelOptionPaths...)

	var filtered map[string]any
	switch mode {
	case modelOptionPolicyDenylist:
		denied = append(denied, modelOptionPathsForProtocol(cfg.DeniedPathsJSON, protocolKey)...)
		filtered = policyOptions
	default:
		filtered = make(map[string]any)
		// 产品化媒体参数兜底放行在前，管理员配置的白名单在其上叠加（重复路径拷贝幂等）。
		for _, path := range mediaOptionBaselinePathsFor(protocolKey) {
			copyModelOptionPath(filtered, policyOptions, path)
		}
		for _, path := range modelOptionPathsForProtocol(cfg.AllowedPathsJSON, protocolKey) {
			copyModelOptionPath(filtered, policyOptions, path)
		}
	}

	for _, path := range denied {
		deleteModelOptionPath(filtered, path)
	}
	sanitizeModelOptionValues(filtered, protocolKey)
	if len(nativeTools) > 0 {
		if filtered == nil {
			filtered = make(map[string]any)
		}
		filtered["tools"] = nativeTools
	}
	if len(filtered) == 0 {
		return nil
	}
	return filtered
}

// modelCapabilityDefaultOptions 提取管理员在模型能力 JSON 中声明的默认请求参数。
func modelCapabilityDefaultOptions(raw string) map[string]any {
	value := strings.TrimSpace(raw)
	if value == "" {
		return nil
	}
	var config struct {
		DefaultOptions map[string]any `json:"defaultOptions"`
	}
	if err := json.Unmarshal([]byte(value), &config); err != nil {
		return nil
	}
	return cloneModelOptionMap(config.DefaultOptions)
}

func modelCapabilityLockedOptionPaths(raw string) [][]string {
	value := strings.TrimSpace(raw)
	if value == "" {
		return nil
	}
	var config struct {
		LockedOptionPaths []string `json:"lockedOptionPaths"`
	}
	if err := json.Unmarshal([]byte(value), &config); err != nil {
		return nil
	}
	paths := make([][]string, 0, len(config.LockedOptionPaths))
	for _, value := range config.LockedOptionPaths {
		if path := splitModelOptionPath(value); len(path) > 0 {
			paths = append(paths, path)
		}
	}
	return paths
}

// mergeModelOptionDefaults 以能力默认值为基础合并本次显式参数，并对锁定路径恢复默认值。
func mergeModelOptionDefaults(defaults map[string]any, options map[string]any, lockedPaths [][]string) map[string]any {
	merged := cloneModelOptionMap(defaults)
	if merged == nil {
		merged = make(map[string]any, len(options))
	}
	mergeModelOptionMap(merged, options)
	for _, path := range lockedPaths {
		if value, ok := readModelOptionPath(defaults, path); ok {
			writeModelOptionPath(merged, path, cloneModelOptionValue(value))
		}
	}
	if len(merged) == 0 {
		return nil
	}
	return merged
}

// nativeProviderToolsFromOption 将用户 options.tools 收敛为当前协议允许的官方原生工具。
// 普通参数白名单不处理 tools，避免用户通过自由 JSON 绕过官方工具控制。
func nativeProviderToolsFromOption(protocolKey string, raw any, capabilitiesJSON string) []map[string]any {
	rawTools := providerToolOptionPayloads(raw)
	if len(rawTools) == 0 {
		return nil
	}
	allowedTools := nativeToolCapabilitiesFromConfig(capabilitiesJSON, protocolKey)
	if len(allowedTools) == 0 {
		return nil
	}
	seen := make(map[string]struct{}, len(rawTools))
	tools := make([]map[string]any, 0, len(rawTools))
	for _, rawTool := range rawTools {
		tool, identity, ok := nativeProviderToolPayload(protocolKey, rawTool, allowedTools)
		if !ok {
			continue
		}
		if _, exists := seen[identity]; exists {
			continue
		}
		seen[identity] = struct{}{}
		tools = append(tools, tool)
	}
	return tools
}

func nativeProviderToolPayload(protocolKey string, rawTool map[string]any, allowedTools []nativeToolCapability) (map[string]any, string, bool) {
	definition, tool, ok := nativetool.PayloadFromOption(protocolKey, rawTool)
	if ok {
		if capability, allowed := nativeToolCapabilityByDefinition(allowedTools, definition); allowed {
			return nativetool.CanonicalPayload(definition, mergeNativeToolPayload(tool, capability.Payload)), capability.Identity(), true
		}
	}
	for _, capability := range allowedTools {
		if !nativeToolCapabilityMatchesRawTool(capability, rawTool) {
			continue
		}
		return mergeNativeToolPayload(rawTool, capability.Payload), capability.Identity(), true
	}
	return nil, "", false
}

type nativeToolCapability struct {
	Key      string
	Protocol string
	Type     string
	Payload  map[string]any
}

func (tool nativeToolCapability) Identity() string {
	parts := []string{
		strings.TrimSpace(tool.Key),
		strings.TrimSpace(tool.Protocol),
		strings.TrimSpace(tool.Type),
	}
	if parts[0] != "" {
		return strings.Join(parts, ":")
	}
	return strings.Join(parts[1:], ":")
}

func nativeToolCapabilitiesFromConfig(raw string, protocolKey string) []nativeToolCapability {
	value := strings.TrimSpace(raw)
	if value == "" {
		return nil
	}
	var config struct {
		NativeTools []struct {
			Key            string         `json:"key"`
			ToolKey        string         `json:"toolKey"`
			Protocol       string         `json:"protocol"`
			Protocols      []string       `json:"protocols"`
			Type           string         `json:"type"`
			Enabled        *bool          `json:"enabled"`
			Payload        map[string]any `json:"payload"`
			DefaultEnabled bool           `json:"defaultEnabled"`
		} `json:"nativeTools"`
		NativeToolKeys []string       `json:"nativeToolKeys"`
		DefaultOptions map[string]any `json:"defaultOptions"`
	}
	if err := json.Unmarshal([]byte(value), &config); err != nil {
		return nil
	}
	capabilities := make([]nativeToolCapability, 0, len(config.NativeTools)+len(config.NativeToolKeys))
	seen := make(map[string]struct{})
	addCapability := func(tool nativeToolCapability) {
		tool.Key = strings.TrimSpace(tool.Key)
		tool.Protocol = strings.TrimSpace(tool.Protocol)
		tool.Type = strings.TrimSpace(tool.Type)
		if tool.Type == "" {
			tool.Type = strings.TrimSpace(modelOptionStringValue(tool.Payload["type"]))
		}
		if tool.Protocol == "" {
			tool.Protocol = protocolKey
		}
		if tool.Type == "" && len(tool.Payload) == 0 {
			return
		}
		identity := tool.Identity()
		if _, ok := seen[identity]; ok {
			return
		}
		seen[identity] = struct{}{}
		capabilities = append(capabilities, tool)
	}

	for _, item := range config.NativeTools {
		if item.Enabled != nil && !*item.Enabled {
			continue
		}
		key := strings.TrimSpace(item.Key)
		if key == "" {
			key = strings.TrimSpace(item.ToolKey)
		}
		protocols := nativeToolCapabilityProtocols(item.Protocols, item.Protocol)
		definitions := nativeToolDefinitionsByKey(key)
		if len(protocols) == 0 {
			protocols = nativeToolDefinitionProtocols(definitions)
		}
		if len(protocols) == 0 {
			protocols = []string{protocolKey}
		}
		if len(definitions) > 0 {
			for _, protocol := range protocols {
				definition, ok := nativeToolDefinitionForProtocol(definitions, protocol)
				if !ok {
					addCapability(nativeToolCapability{
						Key:      key,
						Protocol: protocol,
						Type:     item.Type,
						Payload:  cloneModelOptionMap(item.Payload),
					})
					continue
				}
				addCapability(nativeToolCapability{
					Key:      key,
					Protocol: textutil.FirstNonEmpty(protocol, definition.Protocol, protocolKey),
					Type:     textutil.FirstNonEmpty(item.Type, definition.Type),
					Payload:  nativetool.CanonicalPayload(definition, item.Payload),
				})
			}
			continue
		}
		for _, protocol := range protocols {
			addCapability(nativeToolCapability{
				Key:      key,
				Protocol: textutil.FirstNonEmpty(protocol, protocolKey),
				Type:     item.Type,
				Payload:  cloneModelOptionMap(item.Payload),
			})
		}
	}

	for _, key := range config.NativeToolKeys {
		key = strings.TrimSpace(key)
		if key == "" {
			continue
		}
		for _, definition := range nativetool.Definitions() {
			if definition.Key != key {
				continue
			}
			addCapability(nativeToolCapability{
				Key:      definition.Key,
				Protocol: definition.Protocol,
				Type:     definition.Type,
				Payload:  definition.Payload,
			})
		}
	}

	for _, tool := range providerToolOptionPayloads(config.DefaultOptions["tools"]) {
		definition, _, ok := nativetool.PayloadFromOption(protocolKey, tool)
		if ok {
			addCapability(nativeToolCapability{
				Key:      definition.Key,
				Protocol: definition.Protocol,
				Type:     definition.Type,
				Payload:  nativetool.CanonicalPayload(definition, tool),
			})
		}
	}
	return capabilities
}

func nativeToolCapabilityProtocols(values []string, single string) []string {
	protocols := make([]string, 0, len(values)+1)
	seen := make(map[string]struct{}, len(values)+1)
	add := func(value string) {
		value = strings.TrimSpace(value)
		if value == "" {
			return
		}
		if _, ok := seen[value]; ok {
			return
		}
		seen[value] = struct{}{}
		protocols = append(protocols, value)
	}
	for _, value := range values {
		add(value)
	}
	add(single)
	return protocols
}

func nativeToolDefinitionsByKey(key string) []nativetool.Definition {
	key = strings.TrimSpace(key)
	if key == "" {
		return nil
	}
	definitions := make([]nativetool.Definition, 0, 2)
	for _, definition := range nativetool.Definitions() {
		if definition.Key == key {
			definitions = append(definitions, definition)
		}
	}
	return definitions
}

func nativeToolDefinitionProtocols(definitions []nativetool.Definition) []string {
	protocols := make([]string, 0, len(definitions))
	seen := make(map[string]struct{}, len(definitions))
	for _, definition := range definitions {
		protocol := strings.TrimSpace(definition.Protocol)
		if protocol == "" {
			continue
		}
		if _, ok := seen[protocol]; ok {
			continue
		}
		seen[protocol] = struct{}{}
		protocols = append(protocols, protocol)
	}
	return protocols
}

func nativeToolDefinitionForProtocol(definitions []nativetool.Definition, protocol string) (nativetool.Definition, bool) {
	protocol = strings.TrimSpace(protocol)
	for _, definition := range definitions {
		if definition.Protocol == protocol {
			return definition, true
		}
	}
	return nativetool.Definition{}, false
}

func nativeToolCapabilityByDefinition(items []nativeToolCapability, definition nativetool.Definition) (nativeToolCapability, bool) {
	for _, item := range items {
		if item.Key != "" && item.Key == definition.Key {
			if item.Protocol == "" || item.Protocol == definition.Protocol {
				return item, true
			}
		}
		if item.Type == definition.Type && (item.Protocol == "" || item.Protocol == definition.Protocol) {
			return item, true
		}
	}
	return nativeToolCapability{}, false
}

func nativeToolCapabilityMatchesRawTool(capability nativeToolCapability, rawTool map[string]any) bool {
	rawType := strings.TrimSpace(modelOptionStringValue(rawTool["type"]))
	if rawType != "" && capability.Type != "" {
		return rawType == capability.Type
	}
	payloadType := strings.TrimSpace(modelOptionStringValue(capability.Payload["type"]))
	if rawType != "" && payloadType != "" {
		return rawType == payloadType
	}
	if capability.Type != "" {
		return false
	}
	for key := range capability.Payload {
		if key == "type" {
			continue
		}
		if _, ok := rawTool[key]; ok {
			return true
		}
	}
	return false
}

func mergeNativeToolPayload(raw map[string]any, base map[string]any) map[string]any {
	payload := cloneModelOptionMap(raw)
	if payload == nil {
		payload = make(map[string]any)
	}
	for _, path := range hardDeniedModelOptionPaths {
		deleteModelOptionPath(payload, path)
	}
	mergeModelOptionMap(payload, base)
	return payload
}

func mergeModelOptionMap(dst map[string]any, src map[string]any) {
	for key, value := range src {
		srcMap, srcIsMap := value.(map[string]any)
		dstMap, dstIsMap := dst[key].(map[string]any)
		if srcIsMap && dstIsMap && dstMap != nil {
			mergeModelOptionMap(dstMap, srcMap)
			continue
		}
		dst[key] = cloneModelOptionValue(value)
	}
}

func modelOptionStringValue(value any) string {
	if typed, ok := value.(string); ok {
		return typed
	}
	return ""
}

// providerToolOptionPayloads 从自由 JSON 中提取 tools 数组对象。
func providerToolOptionPayloads(raw any) []map[string]any {
	switch typed := raw.(type) {
	case []map[string]any:
		return append([]map[string]any(nil), typed...)
	case []any:
		items := make([]map[string]any, 0, len(typed))
		for _, item := range typed {
			if payload, ok := item.(map[string]any); ok {
				items = append(items, payload)
			}
		}
		return items
	default:
		return nil
	}
}

func sanitizeModelOptionValues(options map[string]any, protocolKey string) {
	if len(options) == 0 {
		return
	}
	switch protocolKey {
	case "openai_chat_completions", "openai_responses", "openrouter_responses":
		sanitizeOpenAIServiceTier(options)
	case "xai_video":
		llm.SanitizeXAIVideoOptions(options)
	case "xai_video_extensions":
		llm.SanitizeXAIVideoExtensionOptions(options)
	case "openai_video_generations":
		llm.SanitizeOpenAIVideoOptions(options)
	case "openai_image_generations", "openai_image_edits":
		value, ok := modelParamIntFromOption(options["partial_images"])
		if !ok {
			delete(options, "partial_images")
			return
		}
		if value < 0 || value > 3 {
			delete(options, "partial_images")
		}
	}
}

func sanitizeOpenAIServiceTier(options map[string]any) {
	serviceTier, ok := options["service_tier"]
	if !ok {
		return
	}
	value, ok := serviceTier.(string)
	if !ok {
		delete(options, "service_tier")
		return
	}
	switch strings.TrimSpace(strings.ToLower(value)) {
	case "default", "flex", "priority":
		options["service_tier"] = strings.TrimSpace(strings.ToLower(value))
	default:
		delete(options, "service_tier")
	}
}

func modelParamIntFromOption(value any) (int, bool) {
	switch typed := value.(type) {
	case int:
		return typed, true
	case int64:
		return int(typed), true
	case float64:
		return int(typed), true
	default:
		return 0, false
	}
}

func modelOptionPolicyProtocolKey(protocol string) string {
	switch llm.NormalizeAdapter(protocol) {
	case "openai":
		return "openai_responses"
	case "openrouter":
		return "openrouter_responses"
	case "anthropic", "claude":
		return "anthropic_messages"
	case "xai", "grok":
		return "xai_responses"
	case "google", "gemini":
		return "gemini_generate_content"
	case llm.AdapterGoogleGenerateContent:
		return "gemini_generate_content"
	case llm.AdapterGoogleImageGeneration:
		return "google_image_generation"
	case llm.AdapterGeminiInteractions:
		return "gemini_interactions"
	case llm.AdapterOpenAIChatCompletions:
		return "openai_chat_completions"
	case llm.AdapterOpenRouterChat:
		return "openrouter_chat_completions"
	case llm.AdapterOpenRouterResponses:
		return "openrouter_responses"
	case llm.AdapterOpenAIImageGenerations:
		return "openai_image_generations"
	case llm.AdapterOpenAIImageEdits:
		return "openai_image_edits"
	case llm.AdapterAnthropicMessages:
		return "anthropic_messages"
	case llm.AdapterXAIImage:
		return "xai_image"
	case llm.AdapterXAIImageEdits:
		return "xai_image_edits"
	case llm.AdapterXAIVideo:
		return "xai_video"
	case llm.AdapterXAIVideoExtensions:
		return "xai_video_extensions"
	case llm.AdapterOpenAIVideo:
		return "openai_video_generations"
	case llm.AdapterXAIResponses:
		return "xai_responses"
	default:
		return "openai_responses"
	}
}

func modelOptionPathsForProtocol(raw string, protocol string) [][]string {
	var config map[string][]string
	if err := json.Unmarshal([]byte(strings.TrimSpace(raw)), &config); err != nil {
		return nil
	}
	paths := make([][]string, 0, len(config["default"])+len(config[protocol]))
	for _, value := range append(config["default"], config[protocol]...) {
		if path := splitModelOptionPath(value); len(path) > 0 {
			paths = append(paths, path)
		}
	}
	return paths
}

func splitModelOptionPath(value string) []string {
	value = strings.TrimSpace(value)
	if value == "" || strings.ContainsAny(value, " \t\r\n") {
		return nil
	}
	parts := strings.Split(value, ".")
	for _, part := range parts {
		if part == "" {
			return nil
		}
	}
	return parts
}

func copyModelOptionPath(dst map[string]any, src map[string]any, path []string) {
	value, ok := copyModelOptionValueAtPath(src, path)
	if !ok {
		return
	}
	mergeModelOptionPathValue(dst, value)
}

func copyModelOptionValueAtPath(value any, path []string) (any, bool) {
	if len(path) == 0 {
		return cloneModelOptionValue(value), true
	}
	switch typed := value.(type) {
	case map[string]any:
		child, ok := typed[path[0]]
		if !ok {
			return nil, false
		}
		copied, ok := copyModelOptionValueAtPath(child, path[1:])
		if !ok {
			return nil, false
		}
		return map[string]any{path[0]: copied}, true
	case []any:
		items := make([]any, len(typed))
		matched := false
		for index, item := range typed {
			copied, ok := copyModelOptionValueAtPath(item, path)
			if ok {
				items[index] = copied
				matched = true
			} else {
				items[index] = map[string]any{}
			}
		}
		if !matched {
			return nil, false
		}
		return items, true
	default:
		return nil, false
	}
}

func mergeModelOptionPathValue(dst map[string]any, value any) {
	payload, ok := value.(map[string]any)
	if !ok {
		return
	}
	mergeModelOptionPathMap(dst, payload)
}

func mergeModelOptionPathMap(dst map[string]any, src map[string]any) {
	for key, value := range src {
		if existingMap, ok := dst[key].(map[string]any); ok {
			if incomingMap, ok := value.(map[string]any); ok {
				mergeModelOptionPathMap(existingMap, incomingMap)
				continue
			}
		}
		if existingItems, ok := dst[key].([]any); ok {
			if incomingItems, ok := value.([]any); ok {
				dst[key] = mergeModelOptionPathArray(existingItems, incomingItems)
				continue
			}
		}
		dst[key] = cloneModelOptionValue(value)
	}
}

func mergeModelOptionPathArray(existing []any, incoming []any) []any {
	result := make([]any, len(existing))
	for index, item := range existing {
		result[index] = cloneModelOptionValue(item)
	}
	for index, item := range incoming {
		if index >= len(result) {
			result = append(result, cloneModelOptionValue(item))
			continue
		}
		existingMap, existingOK := result[index].(map[string]any)
		incomingMap, incomingOK := item.(map[string]any)
		if existingOK && incomingOK {
			mergeModelOptionPathMap(existingMap, incomingMap)
			continue
		}
		result[index] = cloneModelOptionValue(item)
	}
	return result
}

func readModelOptionPath(src map[string]any, path []string) (any, bool) {
	if len(path) == 0 {
		return nil, false
	}
	current := src
	for index, segment := range path {
		value, ok := current[segment]
		if !ok {
			return nil, false
		}
		if index == len(path)-1 {
			return value, true
		}
		next, ok := value.(map[string]any)
		if !ok {
			return nil, false
		}
		current = next
	}
	return nil, false
}

func writeModelOptionPath(dst map[string]any, path []string, value any) {
	current := dst
	for index, segment := range path {
		if index == len(path)-1 {
			current[segment] = value
			return
		}
		next, ok := current[segment].(map[string]any)
		if !ok {
			next = make(map[string]any)
			current[segment] = next
		}
		current = next
	}
}

func deleteModelOptionPath(dst map[string]any, path []string) {
	if len(path) == 0 || len(dst) == 0 {
		return
	}
	current := dst
	for index, segment := range path {
		if index == len(path)-1 {
			delete(current, segment)
			return
		}
		next, ok := current[segment].(map[string]any)
		if !ok {
			return
		}
		current = next
	}
}

func cloneModelOptionMap(src map[string]any) map[string]any {
	if src == nil {
		return nil
	}
	dst := make(map[string]any, len(src))
	for key, value := range src {
		dst[key] = cloneModelOptionValue(value)
	}
	return dst
}

func cloneModelOptionValue(value any) any {
	switch typed := value.(type) {
	case map[string]any:
		return cloneModelOptionMap(typed)
	case []any:
		items := make([]any, len(typed))
		for index, item := range typed {
			items[index] = cloneModelOptionValue(item)
		}
		return items
	default:
		return typed
	}
}

// shouldApplyReasoningPassbackRequestOptions 判断本轮是否需要下发厂商私有的回传配套入参。
//
// 三个条件缺一不可：
//   - 回传实际生效（路由能力 AND 用户设置），否则等于付费读历史推理却没有历史推理可读；
//   - 该路由确有配套入参要求；
//   - 本轮真实发送的历史里已存在非空推理。这些入参只影响「历史」思维链的处理方式，
//     首轮或非思考模型下发它没有收益，且能规避自建后端把未知顶层字段判为非法入参。
func shouldApplyReasoningPassbackRequestOptions(
	passbackEnabled bool,
	required map[string]any,
	messages []llm.Message,
) bool {
	if !passbackEnabled || len(required) == 0 {
		return false
	}
	return promptCarriesAssistantReasoning(messages)
}

// promptCarriesAssistantReasoning 判断本轮真实发送的历史里是否已有非空 assistant 推理内容。
func promptCarriesAssistantReasoning(messages []llm.Message) bool {
	for _, item := range messages {
		if item.Role == "assistant" && strings.TrimSpace(item.ReasoningContent) != "" {
			return true
		}
	}
	return false
}

// withReasoningPassbackRequestOptions 补齐厂商要求的回传配套入参。
//
// 该入参属于协议正确性而非用户偏好，因此绕过管理员选项白名单——白名单收窄时不应让回传
// 静默退化成「传了字段但模型不读」。但用户或管理员显式声明过的值一律不覆盖：除了已过滤
// 结果，还需回看 rawOptions 与模型能力 defaultOptions，因为白名单模式会把未放行的键丢掉，
// 只看 options 会把管理员刻意设的 false 覆盖成 true。
func withReasoningPassbackRequestOptions(
	options map[string]any,
	required map[string]any,
	rawOptions map[string]any,
	capabilitiesJSON string,
) map[string]any {
	if len(required) == 0 {
		return options
	}
	defaults := modelCapabilityDefaultOptions(capabilitiesJSON)
	for key, value := range required {
		if _, ok := options[key]; ok {
			continue
		}
		if _, ok := rawOptions[key]; ok {
			continue
		}
		if _, ok := defaults[key]; ok {
			continue
		}
		if options == nil {
			options = make(map[string]any, len(required))
		}
		options[key] = value
	}
	return options
}
