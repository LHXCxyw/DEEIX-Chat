package conversation

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"strings"
	"time"

	"github.com/DEEIX-AI/DEEIX-Chat/backend/internal/application/channel"
	appcm "github.com/DEEIX-AI/DEEIX-Chat/backend/internal/application/contentmoderation"
	appupload "github.com/DEEIX-AI/DEEIX-Chat/backend/internal/application/upload"
	domainbilling "github.com/DEEIX-AI/DEEIX-Chat/backend/internal/domain/billing"
	model "github.com/DEEIX-AI/DEEIX-Chat/backend/internal/domain/conversation"
	"github.com/DEEIX-AI/DEEIX-Chat/backend/internal/pkg/filetype"
	"github.com/DEEIX-AI/DEEIX-Chat/backend/internal/pkg/textutil"
	"github.com/DEEIX-AI/DEEIX-Chat/backend/internal/pkg/traceid"
	"github.com/DEEIX-AI/DEEIX-Chat/backend/internal/ports/llm"
	"github.com/DEEIX-AI/DEEIX-Chat/backend/internal/repository"
	"github.com/DEEIX-AI/DEEIX-Chat/backend/internal/shared/background"
	"github.com/DEEIX-AI/DEEIX-Chat/backend/internal/shared/tokenestimate"
	"github.com/google/uuid"
	"go.uber.org/zap"
)

// MediaImageTaskType 表示媒体图片任务类型。
type MediaImageTaskType string

const (
	// MediaImageTaskGeneration 表示纯文本提示词生成图片任务。
	MediaImageTaskGeneration MediaImageTaskType = "image_generation"
	// MediaImageTaskEdit 表示基于输入图片的编辑任务。
	MediaImageTaskEdit MediaImageTaskType = "image_edit"
)

const maxMediaImageEditInputImages = 16

type mediaImageCapabilities struct {
	Image struct {
		Stream *bool `json:"stream"`
	} `json:"image"`
}

// MediaImageInput 定义媒体图片任务的应用层入参。
type MediaImageInput struct {
	UserID                uint
	ConversationID        uint
	RequestID             string
	TaskType              MediaImageTaskType
	Prompt                string
	PlatformModelName     string
	ModelScope            string
	UserModelID           uint
	Options               map[string]any
	ClientRunID           string
	FileIDs               []string
	MaskFileID            string
	ParentMessagePublicID string
	SourceMessagePublicID string
	BranchReason          string
	// UsageAuthorization 是请求级计费授权；路由确定后据此把预算预留抬高到按次预估成本。
	UsageAuthorization *domainbilling.UsageAuthorization
	OnEvent            func(eventType string, payload map[string]any) error
}

// StreamMediaImage 执行图片生成任务并把结果保存为文件对象。
// 图片能力不复用聊天生成链路，只通过图片任务类型和图片协议路由。
func (s *Service) StreamMediaImage(ctx context.Context, input MediaImageInput) (result *SendMessageResult, retErr error) {
	if input.TaskType != MediaImageTaskGeneration && input.TaskType != MediaImageTaskEdit {
		return nil, ErrInvalidMediaGenerationTask
	}
	if s.routeResolver == nil || s.llmClient == nil {
		return nil, ErrModelRouteNotConfigured
	}
	// clientRunID 是媒体任务的幂等键；重复提交不能继续创建 run 和消息。
	runID := normalizeRunID(input.ClientRunID)
	if runID == "" {
		runID = "run_" + normalizePublicID(uuid.NewString())
	}
	startedAt := time.Now()
	conversation, err := s.repo.GetConversationByUser(ctx, input.ConversationID, input.UserID)
	if err != nil {
		return nil, ErrConversationNotFound
	}

	normalizedBranchReason := normalizeBranchReason(input.BranchReason)
	branchState, err := s.resolveMessageBranch(ctx, input.ConversationID, input.UserID, input.ParentMessagePublicID, input.SourceMessagePublicID, normalizedBranchReason)
	if err != nil {
		return nil, err
	}
	reuseUserMessage := branchState.ReuseUserMessage != nil
	if reuseUserMessage {
		input.Prompt = branchState.ReuseUserMessage.Content
		input.FileIDs = parseAttachmentSnapshotFileIDs(branchState.ReuseUserMessage.Attachments)
	}
	if strings.TrimSpace(input.Prompt) == "" {
		return nil, ErrMediaImagePromptRequired
	}
	if input.TaskType == MediaImageTaskGeneration && len(input.FileIDs) > 0 {
		return nil, ErrMediaImageGenerationRejectsInputs
	}
	if input.TaskType == MediaImageTaskEdit && len(input.FileIDs) == 0 {
		return nil, ErrMediaImageEditInputRequired
	}
	platformModelName := strings.TrimSpace(input.PlatformModelName)
	useDefaultRoute := platformModelName == "" && input.UserModelID == 0 && !strings.EqualFold(strings.TrimSpace(input.ModelScope), "user")
	if !useDefaultRoute && platformModelName == "" {
		platformModelName = strings.TrimSpace(conversation.Model)
	}
	if !useDefaultRoute && platformModelName == "" {
		return nil, ErrModelRouteNotConfigured
	}
	taskRouteType := channel.TaskTypeImageGeneration
	endpoint := llm.EndpointImageGenerations
	if input.TaskType == MediaImageTaskEdit {
		taskRouteType = channel.TaskTypeImageEdit
		endpoint = llm.EndpointImageEdits
	}
	run := &model.Run{
		RunID:              runID,
		RequestID:          strings.TrimSpace(input.RequestID),
		UserID:             input.UserID,
		ConversationID:     input.ConversationID,
		TaskType:           string(input.TaskType),
		Endpoint:           endpoint,
		Provider:           strings.TrimSpace(conversation.Provider),
		RequestedModelName: platformModelName,
		Status:             "running",
		StartedAt:          startedAt,
	}
	if err = s.claimConversationRun(ctx, run); err != nil {
		return nil, err
	}
	var moderationCoord *appcm.RunCoordinator
	var userMessage *model.Message
	var assistantMessage *model.Message
	defer func() {
		// On generation failure, still finish input-only moderation when active.
		if retErr != nil && moderationCoord != nil {
			if result == nil && userMessage != nil && assistantMessage != nil {
				result = &SendMessageResult{
					UserMessage:      *userMessage,
					AssistantMessage: *assistantMessage,
					Billable:         false,
					StartedAt:        startedAt,
				}
			}
			moderationCtx, cancelModeration := background.WithTimeout(ctx, moderationFinalizationTimeout)
			s.completeModerationAfterFailure(moderationCtx, moderationCoord, result)
			cancelModeration()
		}
		endedAt := time.Now()
		run.EndedAt = &endedAt
		run.TotalLatencyMS = endedAt.Sub(startedAt).Milliseconds()
		switch {
		case result != nil && result.IsModerationBlocked():
			applyBlockedRunFields(run, result)
		case retErr == nil:
			run.Status = "success"
			if result != nil {
				applyModerationRunState(run, result)
			}
		case errors.Is(retErr, ErrMessageGenerationCanceled):
			run.Status = "canceled"
			run.ErrorCode = classifyRunErrorCode(retErr)
			run.ErrorMessage = textutil.TruncateTrimmed(messageErrorSummary(retErr), 255)
			if result != nil {
				applyModerationRunState(run, result)
			}
		default:
			run.Status = "error"
			run.ErrorCode = classifyRunErrorCode(retErr)
			run.ErrorMessage = textutil.TruncateTrimmed(messageErrorSummary(retErr), 255)
			if result != nil {
				applyModerationRunState(run, result)
			}
		}
		persistCtx, cancelPersist := background.WithTimeout(ctx, 5*time.Second)
		defer cancelPersist()
		if err := s.repo.UpdateConversationRun(persistCtx, run); err != nil && s.logger != nil {
			s.logger.Error("update_media_conversation_run_failed",
				zap.String("trace_id", traceid.FromContext(ctx)),
				zap.String("run_id", run.RunID),
				zap.Error(err),
			)
		}
	}()
	cancelCtx, cancel := context.WithCancel(ctx)
	ctx = cancelCtx
	if err = s.generationStreams.register(ctx, runID, input.UserID, conversation.PublicID, cancel); err != nil {
		return nil, err
	}

	var route *channel.ResolvedRoute
	if useDefaultRoute {
		resolver, ok := s.routeResolver.(defaultRouteResolver)
		if !ok {
			return nil, ErrModelRouteNotConfigured
		}
		route, err = resolver.ResolveDefaultRoute(ctx, channel.ResolveRouteInput{
			TaskType:       taskRouteType,
			Scope:          channel.RouteScopeUser,
			UserID:         input.UserID,
			ConversationID: input.ConversationID,
			RequestID:      strings.TrimSpace(input.RequestID),
		})
	} else {
		route, err = s.routeResolver.ResolveRoute(ctx, channel.ResolveRouteInput{
			PlatformModelName: platformModelName,
			ModelScope:        input.ModelScope,
			UserModelID:       input.UserModelID,
			TaskType:          taskRouteType,
			Scope:             channel.RouteScopeUser,
			UserID:            input.UserID,
			ConversationID:    input.ConversationID,
			RequestID:         strings.TrimSpace(input.RequestID),
		})
	}
	if err != nil {
		return nil, mapRouteResolutionError(err)
	}
	if input.TaskType == MediaImageTaskGeneration && !llm.IsImageGenerationAdapter(route.Protocol) {
		return nil, ErrMediaRouteProtocolMismatch
	}
	if input.TaskType == MediaImageTaskEdit && !llm.IsImageEditAdapter(route.Protocol) {
		return nil, ErrMediaRouteProtocolMismatch
	}
	run.ProviderProtocol = route.Protocol
	run.UpstreamID = route.UpstreamID
	run.UpstreamModelID = route.UpstreamModelID
	run.UpstreamName = route.UpstreamName
	run.PlatformModelName = route.PlatformModelName
	run.RoutedBindingCode = route.BindingCode
	run.ModelVendor = route.ModelVendor
	run.ModelIcon = route.ModelIcon
	run.UpstreamModelName = route.UpstreamModel
	if err = s.ensureUsageBudgetCoversEstimate(ctx, input.UsageAuthorization, route, input.Options, usageBudgetEstimate{CallCount: 1}); err != nil {
		return nil, err
	}
	// 图片任务会把会话当前模型更新为实际执行的图片模型；标题、标签等内部文本任务会单独回退到聊天模型。
	if strings.TrimSpace(conversation.Model) != strings.TrimSpace(route.PlatformModelName) {
		conversation.Model = strings.TrimSpace(route.PlatformModelName)
		conversation.Provider = inferProvider(conversation.Model)
		run.Provider = conversation.Provider
		if err = s.repo.UpdateConversationModel(ctx, input.ConversationID, conversation.Model, conversation.Provider); err != nil {
			return nil, err
		}
	}
	resolvedAttachments, imageEditParts, err := s.resolveMediaImageEditInputs(ctx, input)
	if err != nil {
		return nil, err
	}
	maskPart, err := s.resolveMediaImageEditMask(ctx, input.UserID, input.MaskFileID)
	if err != nil {
		return nil, err
	}
	attachmentsJSON := marshalAttachmentSnapshots(resolvedAttachments)

	assistantMessage = &model.Message{
		ConversationID: input.ConversationID,
		UserID:         input.UserID,
		PublicID:       normalizePublicID(uuid.NewString()),
		RunID:          runID,
		Role:           "assistant",
		ContentType:    "image",
		Content:        "",
		BranchReason:   normalizedBranchReason,
		Status:         "pending",
		Attachments:    "[]",
	}
	if reuseUserMessage {
		reused := *branchState.ReuseUserMessage
		userMessage = &reused
		assistantMessage.ParentMessageID = &userMessage.ID
		assistantMessage.SourceMessageID = branchState.SourceMessageID
		if err = s.repo.CreateAssistantBranchMessage(ctx, assistantMessage); err != nil {
			retErr = err
			return nil, err
		}
		assistantMessage.ParentPublicID = userMessage.PublicID
		assistantMessage.SourcePublicID = branchState.SourcePublicID
	} else {
		userMessage = &model.Message{
			ConversationID:  input.ConversationID,
			UserID:          input.UserID,
			PublicID:        normalizePublicID(uuid.NewString()),
			ParentMessageID: branchState.ParentMessageID,
			RunID:           runID,
			Role:            "user",
			ContentType:     mediaImageUserContentType(input.TaskType),
			Content:         strings.TrimSpace(input.Prompt),
			BranchReason:    normalizedBranchReason,
			SourceMessageID: branchState.SourceMessageID,
			TokenUsage:      tokenestimate.Estimate(input.Prompt),
			InputTokens:     tokenestimate.Estimate(input.Prompt),
			Status:          "success",
			Attachments:     attachmentsJSON,
		}
		userAttachmentRows := make([]model.Attachment, 0, len(resolvedAttachments))
		if len(resolvedAttachments) > 0 {
			now := time.Now()
			for _, item := range resolvedAttachments {
				userAttachmentRows = append(userAttachmentRows, model.Attachment{
					ConversationID: input.ConversationID,
					UserID:         input.UserID,
					FileID:         strings.TrimSpace(item.FileID),
					Kind:           normalizeAttachmentKind(item.Kind, item.MimeType),
					FileName:       strings.TrimSpace(item.FileName),
					MimeType:       strings.TrimSpace(item.MimeType),
					FileSize:       item.FileSize,
					SHA256:         strings.TrimSpace(item.SHA256),
					StoragePath:    strings.TrimSpace(item.StoragePath),
					Status:         "active",
					MetaJSON:       strings.TrimSpace(item.MetaJSON),
					UploadedAt:     now,
				})
			}
		}

		// 媒体任务同样产生一个完整消息回合，初始本地写入必须原子提交。
		if err = s.repo.CreateMessagePairWithUserAttachments(ctx, userMessage, assistantMessage, userAttachmentRows); err != nil {
			retErr = err
			return nil, err
		}
		userMessage.ParentPublicID = branchState.ParentPublicID
		userMessage.SourcePublicID = branchState.SourcePublicID
		assistantMessage.ParentPublicID = userMessage.PublicID
	}
	traceRecorder := newMessageTraceRecorder(s, ctx, assistantMessage, input.OnEvent)
	defer func() {
		if retErr != nil && (result == nil || !result.IsModerationBlocked()) && traceRecorder != nil {
			traceRecorder.fail(retErr)
			traceRecorder.attachToMessage(assistantMessage)
		}
	}()
	// Prefer explicit FileIDs; fall back to resolved edit attachments.
	moderationFileIDs := append([]string{}, input.FileIDs...)
	if len(moderationFileIDs) == 0 {
		for _, item := range resolvedAttachments {
			if id := strings.TrimSpace(item.FileID); id != "" {
				moderationFileIDs = append(moderationFileIDs, id)
			}
		}
	}
	moderationCoord = s.startModerationRun(ctx, SendMessageInput{
		UserID:             input.UserID,
		ConversationID:     input.ConversationID,
		RequestID:          input.RequestID,
		Content:            strings.TrimSpace(input.Prompt),
		FileIDs:            moderationFileIDs,
		ClientRunID:        runID,
		OnEvent:            input.OnEvent,
		UsageAuthorization: input.UsageAuthorization,
	}, runID, userMessage, assistantMessage)
	emitMediaEvent(input.OnEvent, "queued", "image task queued")

	cfg := s.cfg.Snapshot()
	attributionReferer, attributionTitle := s.llmAttribution()
	routeConfig := llm.RouteConfig{
		Protocol:            route.Protocol,
		BaseURL:             route.BaseURL,
		APIKey:              route.APIKey,
		HeadersJSON:         route.HeadersJSON,
		ConnectTimeoutMS:    route.ConnectTimeoutMS,
		ReadTimeoutMS:       route.ReadTimeoutMS,
		StreamIdleTimeoutMS: route.StreamIdleTimeoutMS,
		Endpoint:            endpoint,
		UpstreamModel:       route.UpstreamModel,
		AttributionReferer:  attributionReferer,
		AttributionTitle:    attributionTitle,
	}
	filteredOptions := filterModelOptions(input.Options, route.Protocol, modelOptionPolicyConfig{
		Mode:                  cfg.ModelOptionPolicyMode,
		AllowedPathsJSON:      cfg.ModelOptionAllowedPaths,
		DeniedPathsJSON:       cfg.ModelOptionDeniedPaths,
		ModelCapabilitiesJSON: route.ModelCapabilitiesJSON,
	})
	if llm.NormalizeAdapter(route.Protocol) == llm.AdapterGeminiInteractions {
		filteredOptions = withGeminiInteractionResponseType(filteredOptions, "image")
		routeConfig.Endpoint = llm.EndpointInteractions
		run.Endpoint = llm.EndpointInteractions
	}
	buildBillableFailure := func(failure error, usage llm.Usage) *SendMessageResult {
		result := buildFailedMediaBillingResult(failedMediaBillingResultInput{
			UserMessage:      userMessage,
			AssistantMessage: assistantMessage,
			Route:            *route,
			EffectiveOptions: filteredOptions,
			Usage:            usage,
			StartedAt:        startedAt,
			Failure:          failure,
			Billable:         true,
		})
		applyMediaRunUsage(run, result)
		return result
	}

	emitMediaEvent(input.OnEvent, "running", mediaImageRunningMessage(input.TaskType))
	generateInput := llm.GenerateInput{
		RequestID:      strings.TrimSpace(input.RequestID),
		ConversationID: input.ConversationID,
		Messages: []llm.Message{{
			Role:    "user",
			Content: strings.TrimSpace(input.Prompt),
		}},
		Options: filteredOptions,
	}
	if input.TaskType == MediaImageTaskEdit {
		parts := make([]llm.ContentPart, 0, 1+len(imageEditParts))
		parts = append(parts, llm.ContentPart{
			Kind: llm.ContentPartText,
			Text: strings.TrimSpace(input.Prompt),
		})
		parts = append(parts, imageEditParts...)
		generateInput.Messages = []llm.Message{{
			Role:  "user",
			Parts: parts,
		}}
		generateInput.ImageEditMask = maskPart
	}
	var output *llm.GenerateOutput
	if mediaImageStreamEnabled(routeConfig.Protocol, routeConfig.UpstreamModel, route.ModelCapabilitiesJSON) {
		output, err = s.llmClient.GenerateStream(ctx, routeConfig, generateInput, func(event llm.GenerateStreamEvent) error {
			if event.Usage != (llm.Usage{}) && input.OnEvent != nil {
				if streamErr := input.OnEvent("usage", map[string]any{
					"input_tokens":       event.Usage.InputTokens,
					"output_tokens":      event.Usage.OutputTokens,
					"cache_read_tokens":  event.Usage.CacheReadTokens,
					"cache_write_tokens": event.Usage.CacheWriteTokens,
					"reasoning_tokens":   event.Usage.ReasoningTokens,
				}); streamErr != nil {
					return streamErr
				}
			}
			if event.GeneratedImage != nil && event.GeneratedImagePartial {
				return emitMediaImageDelta(input.OnEvent, event)
			}
			return nil
		})
	} else {
		output, err = s.llmClient.Generate(ctx, routeConfig, generateInput)
	}
	if err != nil {
		if s.isCanceledMediaGeneration(ctx, runID, err) {
			retErr = ErrMessageGenerationCanceled
			result, cancelErr := s.completeCanceledMediaGeneration(canceledMediaGenerationInput{
				Context:          ctx,
				Conversation:     conversation,
				UserMessage:      userMessage,
				AssistantMessage: assistantMessage,
				ReuseUserMessage: reuseUserMessage,
				Route:            *route,
				EffectiveOptions: filteredOptions,
				GenerateInput:    generateInput,
				StartedAt:        startedAt,
				Billable:         true,
			})
			if cancelErr != nil {
				retErr = cancelErr
				return nil, cancelErr
			}
			applyMediaRunUsage(run, result)
			return result, nil
		}
		s.routeResolver.MarkRouteFailure(ctx, route, err)
		retErr = wrapUpstreamRequestError(err)
		_ = s.repo.UpdateMessageState(ctx, assistantMessage.ID, "error", classifyRunErrorCode(retErr), textutil.TruncateTrimmed(messageErrorSummary(retErr), 255))
		return nil, retErr
	}
	s.routeResolver.MarkRouteSuccess(ctx, route)
	if output == nil || (len(output.GeneratedImages) == 0 && strings.TrimSpace(output.Text) == "") {
		retErr = ErrUpstreamEmptyResponse
		_ = s.repo.UpdateMessageState(ctx, assistantMessage.ID, "error", classifyRunErrorCode(retErr), textutil.TruncateTrimmed(messageErrorSummary(retErr), 255))
		return buildBillableFailure(retErr, mediaOutputUsage(output)), retErr
	}

	hasGeneratedImages := len(output.GeneratedImages) > 0
	if hasGeneratedImages {
		emitMediaEvent(input.OnEvent, "saving_artifact", "saving image")
	}
	uploaded := make([]model.FileObject, 0, len(output.GeneratedImages))
	attachmentRows := make([]model.Attachment, 0, len(output.GeneratedImages))
	generatedBytesByFileID := make(map[string][]byte, len(output.GeneratedImages))
	// 待保存产物：下载瞬时失败时保留上游 URL 引用，保存职责移交输出节点逐个重试
	pendingArtifacts := make([]pendingImageArtifact, 0)
	now := time.Now()
	for i, image := range output.GeneratedImages {
		data, mimeType, readErr := s.readGeneratedImage(ctx, image, route.BaseURL)
		if readErr != nil && isRetryableGeneratedMediaDownload(readErr) {
			// 下载类瞬时故障自动重试一次，多数网络抖动在此消化
			data, mimeType, readErr = s.readGeneratedImage(ctx, image, route.BaseURL)
		}
		if readErr != nil {
			if url := strings.TrimSpace(image.URL); url != "" && isRetryableGeneratedMediaDownload(readErr) {
				// 生成已成功：登记待保存引用，交由输出节点重试下载，不占用生成任务状态
				pendingArtifacts = append(pendingArtifacts, pendingImageArtifact{URL: url, MimeType: mimeType, Index: i})
				continue
			}
			retErr = s.finalizeGeneratedMediaArtifactFailure(ctx, run, assistantMessage.ID, i+1, len(output.GeneratedImages), readErr)
			return buildBillableFailure(retErr, output.Usage), retErr
		}
		fileName := generatedImageFileName(route.PlatformModelName, now, i, len(output.GeneratedImages), mimeType)
		uploadInput := appupload.UploadFileInput{
			UserID:       input.UserID,
			Purpose:      "generated_image",
			FileName:     fileName,
			MimeType:     mimeType,
			DeclaredSize: int64(len(data)),
		}
		uploadResult, uploadErr := s.uploadSvc.UploadFile(ctx, uploadInputWith(uploadInput, data))
		if uploadErr != nil {
			// 上传瞬时故障自动重试一次（数据仍在内存，仅重试传输）
			uploadResult, uploadErr = s.uploadSvc.UploadFile(ctx, uploadInputWith(uploadInput, data))
		}
		if uploadErr != nil {
			retErr = uploadErr
			_ = s.repo.UpdateMessageState(ctx, assistantMessage.ID, "error", classifyRunErrorCode(retErr), textutil.TruncateTrimmed(messageErrorSummary(retErr), 255))
			return buildBillableFailure(uploadErr, output.Usage), uploadErr
		}
		file := uploadResult.File
		uploaded = append(uploaded, file)
		generatedBytesByFileID[file.FileID] = data
		attachmentRows = append(attachmentRows, model.Attachment{
			ConversationID: input.ConversationID,
			MessageID:      assistantMessage.ID,
			UserID:         input.UserID,
			FileID:         file.FileID,
			Kind:           "image",
			FileName:       file.FileName,
			MimeType:       file.DetectedMIME,
			FileSize:       file.SizeBytes,
			SHA256:         file.SHA256,
			StoragePath:    file.StoragePath,
			Status:         "active",
			UploadedAt:      now,
		})
	}
	if len(pendingArtifacts) > 0 {
		s.pendingArtifacts.Register(run.RunID, pendingArtifacts)
		indexes := make([]int, 0, len(pendingArtifacts))
		for _, artifact := range pendingArtifacts {
			indexes = append(indexes, artifact.Index)
		}
		emitMediaArtifactPendingEvent(input.OnEvent, run.RunID, "image", indexes)
	}
	if hasGeneratedImages && len(attachmentRows) == 0 {
		// 产物全部待重试：生成已成功（计费保留），流以 completed 结束；
		// 消息标记待重试错误态，输出节点重试成功后由补写路径恢复。
		retErr = ErrMediaArtifactPending
		_ = s.repo.UpdateMessageState(ctx, assistantMessage.ID, "error", classifyRunErrorCode(retErr), textutil.TruncateTrimmed(messageErrorSummary(retErr), 255))
		return buildBillableFailure(retErr, output.Usage), nil
	}
	usage := output.Usage
	if reuseUserMessage {
		assistantMessage.InputTokens = usage.InputTokens
		assistantMessage.CacheReadTokens = usage.CacheReadTokens
		assistantMessage.CacheWriteTokens = usage.CacheWriteTokens
	} else {
		userMessage.InputTokens = usage.InputTokens
		userMessage.CacheReadTokens = usage.CacheReadTokens
		userMessage.CacheWriteTokens = usage.CacheWriteTokens
		userMessage.TokenUsage = usage.InputTokens + usage.CacheReadTokens + usage.CacheWriteTokens
	}

	contentType := "image"
	content := generatedImageMarkdown(uploaded)
	if !hasGeneratedImages {
		contentType = "text"
		content = strings.TrimSpace(output.Text)
	}
	latencyMS := time.Since(startedAt).Milliseconds()
	// 上游与文件上传已完成后，数据库侧的附件、用量和完成态仍需保持原子一致。
	if reuseUserMessage {
		if err = s.repo.CompleteAssistantMessageWithGeneratedAttachments(ctx,
			assistantMessage.ID,
			repository.AssistantMessageCompletionUpdate{
				ContentType:      contentType,
				Content:          content,
				InputTokens:      usage.InputTokens,
				OutputTokens:     usage.OutputTokens,
				CacheReadTokens:  usage.CacheReadTokens,
				CacheWriteTokens: usage.CacheWriteTokens,
				ReasoningTokens:  usage.ReasoningTokens,
				LatencyMS:        latencyMS,
				Status:           "success",
			},
			attachmentRows,
		); err != nil {
			retErr = err
			return buildBillableFailure(err, output.Usage), err
		}
	} else {
		if err = s.repo.CompleteAssistantMessageWithAttachments(ctx,
			userMessage.ID,
			repository.MessageUsageUpdate{
				InputTokens:      usage.InputTokens,
				CacheReadTokens:  usage.CacheReadTokens,
				CacheWriteTokens: usage.CacheWriteTokens,
			},
			assistantMessage.ID,
			repository.AssistantMessageCompletionUpdate{
				ContentType:     contentType,
				Content:         content,
				OutputTokens:    usage.OutputTokens,
				ReasoningTokens: usage.ReasoningTokens,
				LatencyMS:       latencyMS,
				Status:          "success",
			},
			attachmentRows,
		); err != nil {
			retErr = err
			return buildBillableFailure(err, output.Usage), err
		}
	}
	assistantMessage.Content = content
	assistantMessage.ContentType = contentType
	assistantMessage.OutputTokens = usage.OutputTokens
	assistantMessage.ReasoningTokens = usage.ReasoningTokens
	assistantMessage.TokenUsage = assistantMessage.OutputTokens + assistantMessage.ReasoningTokens
	if reuseUserMessage {
		assistantMessage.TokenUsage += usage.InputTokens + usage.CacheReadTokens + usage.CacheWriteTokens
	}
	assistantMessage.LatencyMS = latencyMS
	assistantMessage.Status = "success"
	assistantMessage.Attachments = string(marshalAttachmentSnapshots(attachmentsFromFiles(uploaded)))
	run.InputTokens = usage.InputTokens
	run.OutputTokens = usage.OutputTokens
	run.CacheReadTokens = usage.CacheReadTokens
	run.CacheWriteTokens = usage.CacheWriteTokens
	run.ReasoningTokens = usage.ReasoningTokens

	result = &SendMessageResult{
		UserMessage:         *userMessage,
		AssistantMessage:    *assistantMessage,
		MetadataRefreshHint: s.resolveConversationMetadataRefreshHint(ctx, *conversation, *userMessage),
		Billable:            true,
		UpstreamID:          route.UpstreamID,
		UpstreamName:        route.UpstreamName,
		IsUserOwnedUpstream: route.UpstreamOwnerUserID != nil,
		UpstreamOwnerUserID: route.UpstreamOwnerUserID,
		UpstreamBillingMode: route.UpstreamBillingMode,
		PlatformModelName:   route.PlatformModelName,
		RoutedBindingCode:   route.BindingCode,
		UpstreamModelName:   route.UpstreamModel,
		UpstreamProtocol:    route.Protocol,
		EffectiveOptions:    filteredOptions,
		UsageSpeed:          usage.Speed,
		UsageServiceTier:    usage.ServiceTier,
		RawUsageJSON:        usage.RawUsageJSON,
		CacheWrite5mTokens:  usage.CacheWrite5mTokens,
		CacheWrite1hTokens:  usage.CacheWrite1hTokens,
		LatencyMS:           latencyMS,
		StartedAt:           startedAt,
	}
	if moderationCoord != nil {
		outputImages := loadOutputImagesFromFiles(moderationCoord, uploaded, generatedBytesByFileID)
		s.completeModerationAfterSuccess(ctx, completeModerationAfterSuccessInput{
			Coordinator:  moderationCoord,
			Result:       result,
			OutputText:   moderationOutputText(output.Text, traceRecorder.upstreamThinkContent()),
			OutputImages: outputImages,
			EmbedInput: SendMessageInput{
				UserID:         input.UserID,
				ConversationID: input.ConversationID,
			},
			ReuseUserMessage: reuseUserMessage,
		})
	}
	return result, nil
}

// mediaOutputUsage 安全提取允许为空的媒体响应 usage。
func mediaOutputUsage(output *llm.GenerateOutput) llm.Usage {
	if output == nil {
		return llm.Usage{}
	}
	return output.Usage
}

func mediaImageUserContentType(taskType MediaImageTaskType) string {
	if taskType == MediaImageTaskEdit {
		return "mixed"
	}
	return "text"
}

func mediaImageRunningMessage(taskType MediaImageTaskType) string {
	if taskType == MediaImageTaskEdit {
		return "editing image"
	}
	return "generating image"
}

// resolveMediaImageEditInputs 读取图片编辑输入图，确保只有图片文件进入图片编辑协议。
func (s *Service) resolveMediaImageEditInputs(ctx context.Context, input MediaImageInput) ([]AttachmentInput, []llm.ContentPart, error) {
	if input.TaskType != MediaImageTaskEdit {
		return nil, nil, nil
	}
	attachments, err := s.resolveAttachments(ctx, input.UserID, input.FileIDs)
	if err != nil {
		return nil, nil, err
	}
	if len(attachments) == 0 || len(attachments) > maxMediaImageEditInputImages {
		if len(attachments) == 0 {
			return nil, nil, ErrMediaImageEditInputRequired
		}
		return nil, nil, ErrMediaImageEditTooManyInputs
	}
	parts := make([]llm.ContentPart, 0, len(attachments))
	for _, attachment := range attachments {
		if normalizeAttachmentKind(attachment.Kind, attachment.MimeType) != "image" {
			return nil, nil, ErrMediaImageEditInputInvalid
		}
		part, readErr := s.readMediaImageEditFile(ctx, input.UserID, attachment.FileID)
		if readErr != nil {
			return nil, nil, readErr
		}
		part.FileName = mediaImageEditInputFileName(attachment.FileName, part.MimeType)
		parts = append(parts, part)
	}
	return attachments, parts, nil
}

func (s *Service) resolveMediaImageEditMask(ctx context.Context, userID uint, fileID string) (*llm.ContentPart, error) {
	if strings.TrimSpace(fileID) == "" {
		return nil, nil
	}
	part, err := s.readMediaImageEditFile(ctx, userID, fileID)
	if err != nil {
		return nil, err
	}
	return &part, nil
}

func (s *Service) readMediaImageEditFile(ctx context.Context, userID uint, fileID string) (llm.ContentPart, error) {
	content, err := s.uploadSvc.OpenFileContent(ctx, userID, strings.TrimSpace(fileID))
	if err != nil {
		return llm.ContentPart{}, err
	}
	defer content.Reader.Close() //nolint:errcheck

	limit := s.cfg.Snapshot().MaxUploadFileBytes
	if limit <= 0 {
		limit = 20 * 1024 * 1024
	}
	data, err := io.ReadAll(io.LimitReader(content.Reader, limit+1))
	if err != nil {
		return llm.ContentPart{}, err
	}
	if int64(len(data)) > limit {
		return llm.ContentPart{}, ErrFileTooLarge
	}
	mimeType := strings.TrimSpace(content.ContentType)
	if mimeType == "" {
		mimeType = strings.TrimSpace(content.File.DetectedMIME)
	}
	data, mimeType, err = normalizeMediaImageEditInput(data, mimeType)
	if err != nil {
		return llm.ContentPart{}, ErrMediaImageEditInputInvalid
	}
	return llm.ContentPart{
		Kind:     llm.ContentPartImage,
		MimeType: mimeType,
		Data:     data,
		FileName: mediaImageEditInputFileName(content.File.FileName, mimeType),
	}, nil
}

// emitMediaEvent 输出媒体任务状态事件；失败不影响主流程。
func emitMediaEvent(onEvent func(string, map[string]any) error, status string, message string, contentType ...string) {
	if onEvent == nil {
		return
	}
	payload := map[string]any{
		"status":  status,
		"message": message,
	}
	if len(contentType) > 0 && strings.TrimSpace(contentType[0]) != "" {
		payload["content_type"] = strings.TrimSpace(contentType[0])
	}
	_ = onEvent("media_status", payload)
}

func emitMediaImageDelta(onEvent func(string, map[string]any) error, event llm.GenerateStreamEvent) error {
	if onEvent == nil || event.GeneratedImage == nil {
		return nil
	}
	image := event.GeneratedImage
	if strings.TrimSpace(image.B64JSON) == "" {
		return nil
	}
	return onEvent("media_image_delta", map[string]any{
		"index":          event.GeneratedImageIndex,
		"b64_json":       image.B64JSON,
		"mime_type":      strings.TrimSpace(image.MIMEType),
		"revised_prompt": strings.TrimSpace(image.RevisedPrompt),
	})
}

func mediaImageStreamEnabled(protocol string, upstreamModel string, capabilitiesJSON string) bool {
	return llm.SupportsImageGenerationStream(protocol, upstreamModel) && !mediaImageStreamExplicitlyDisabled(capabilitiesJSON)
}

func withGeminiInteractionResponseType(options map[string]any, responseType string) map[string]any {
	next := make(map[string]any, len(options)+1)
	for key, value := range options {
		next[key] = value
	}
	format := map[string]any{}
	if raw, ok := next["response_format"].(map[string]any); ok {
		for key, value := range raw {
			format[key] = value
		}
	}
	format["type"] = strings.TrimSpace(responseType)
	next["response_format"] = format
	return next
}

func mediaImageStreamExplicitlyDisabled(capabilitiesJSON string) bool {
	raw := strings.TrimSpace(capabilitiesJSON)
	if raw == "" {
		return false
	}
	var caps mediaImageCapabilities
	if err := json.Unmarshal([]byte(raw), &caps); err != nil {
		return false
	}
	return caps.Image.Stream != nil && !*caps.Image.Stream
}

// uploadInputWith 为数据字节构造上传输入；Reader 单次消费，重试上传必须重建。
func uploadInputWith(input appupload.UploadFileInput, data []byte) appupload.UploadFileInput {
	input.Reader = bytes.NewReader(data)
	return input
}

// readGeneratedImage 读取上游图片结果，并统一校验为可保存的图片字节。
// 上游临时 URL 只用于服务端下载，最终不会直接写入消息内容，避免长期依赖外部地址。
func (s *Service) readGeneratedImage(ctx context.Context, image llm.GeneratedImage, trustedProviderEndpoint string) ([]byte, string, error) {
	mimeType := strings.TrimSpace(image.MIMEType)
	if mimeType == "" {
		mimeType = "image/png"
	}
	if b64 := strings.TrimSpace(image.B64JSON); b64 != "" {
		data, err := base64.StdEncoding.DecodeString(stripBase64DataURLPrefix(b64))
		if err != nil {
			return nil, mimeType, newGeneratedMediaArtifactError("image", "decode", err)
		}
		validated, detectedMIME, validationErr := validateGeneratedImageBytes(data, mimeType)
		if validationErr != nil {
			return nil, mimeType, newGeneratedMediaArtifactError("image", "validation", validationErr)
		}
		return validated, detectedMIME, nil
	}
	url := strings.TrimSpace(image.URL)
	if url == "" {
		return nil, mimeType, ErrUpstreamEmptyResponse
	}
	if s.mediaDownloader == nil {
		return nil, mimeType, newGeneratedMediaArtifactError("image", "configuration", fmt.Errorf("generated media downloader is not configured"))
	}
	cfg := s.cfg.Snapshot()
	limit := cfg.MaxUploadFileBytes
	if limit <= 0 {
		limit = 20 * 1024 * 1024
	}
	data, downloadedMIME, err := s.mediaDownloader.DownloadImage(ctx, url, trustedProviderEndpoint, limit)
	if err != nil {
		if isMediaArtifactResponseTooLarge(err) {
			return nil, mimeType, ErrFileTooLarge
		}
		return nil, mimeType, newGeneratedMediaArtifactError("image", "download", err)
	}
	if strings.HasPrefix(strings.ToLower(strings.TrimSpace(downloadedMIME)), "image/") {
		mimeType = strings.TrimSpace(downloadedMIME)
	}
	validated, detectedMIME, validationErr := validateGeneratedImageBytes(data, mimeType)
	if validationErr != nil {
		return nil, mimeType, newGeneratedMediaArtifactError("image", "validation", validationErr)
	}
	return validated, detectedMIME, nil
}

// stripBase64DataURLPrefix 兼容 data URL 和纯 base64 两种上游返回格式。
func stripBase64DataURLPrefix(value string) string {
	normalized := strings.TrimSpace(value)
	if !strings.HasPrefix(strings.ToLower(normalized), "data:") {
		return normalized
	}
	if index := strings.Index(normalized, ","); index >= 0 {
		return strings.TrimSpace(normalized[index+1:])
	}
	return normalized
}

// validateGeneratedImageBytes 使用文件头重新识别 MIME，防止把非图片响应保存成图片文件。
func validateGeneratedImageBytes(data []byte, declaredMIME string) ([]byte, string, error) {
	detected := detectGeneratedImageMIME(data)
	if detected == "" {
		return nil, strings.TrimSpace(declaredMIME), fmt.Errorf("generated image content is not a supported image")
	}
	return data, detected, nil
}

// detectGeneratedImageMIME 识别当前支持落库的图片格式。
func detectGeneratedImageMIME(data []byte) string {
	if len(data) == 0 {
		return ""
	}
	if len(data) >= 8 && bytes.Equal(data[:8], []byte{0x89, 'P', 'N', 'G', '\r', '\n', 0x1a, '\n'}) {
		return "image/png"
	}
	if len(data) >= 3 && data[0] == 0xff && data[1] == 0xd8 && data[2] == 0xff {
		return "image/jpeg"
	}
	if len(data) >= 12 && bytes.Equal(data[:4], []byte("RIFF")) && bytes.Equal(data[8:12], []byte("WEBP")) {
		return "image/webp"
	}
	if len(data) >= 6 && (bytes.Equal(data[:6], []byte("GIF87a")) || bytes.Equal(data[:6], []byte("GIF89a"))) {
		return "image/gif"
	}
	return ""
}

// generatedImageFileName 使用模型名和生成时间构造稳定可读的文件名。
func generatedImageFileName(modelName string, capturedAt time.Time, index int, total int, mimeType string) string {
	base := sanitizeGeneratedImageFileBase(modelName)
	timestamp := fmt.Sprintf("%s-%03d", capturedAt.Format("20060102-150405"), capturedAt.Nanosecond()/int(time.Millisecond))
	if total > 1 {
		return fmt.Sprintf("%s-%s-%02d%s", base, timestamp, index+1, filetype.ImageExtension(mimeType))
	}
	return fmt.Sprintf("%s-%s%s", base, timestamp, filetype.ImageExtension(mimeType))
}

// sanitizeGeneratedImageFileBase 清理模型名，确保生成文件名不含路径分隔符或不可控字符。
func sanitizeGeneratedImageFileBase(value string) string {
	normalized := strings.TrimSpace(value)
	if normalized == "" {
		return "image"
	}
	var builder strings.Builder
	builder.Grow(len(normalized))
	lastDash := false
	for _, item := range normalized {
		allowed := (item >= 'a' && item <= 'z') ||
			(item >= 'A' && item <= 'Z') ||
			(item >= '0' && item <= '9') ||
			item == '.' ||
			item == '_' ||
			item == '-'
		if allowed {
			builder.WriteRune(item)
			lastDash = false
			continue
		}
		if !lastDash {
			builder.WriteByte('-')
			lastDash = true
		}
	}
	result := strings.Trim(builder.String(), ".-_")
	if result == "" {
		return "image"
	}
	if len(result) > 80 {
		result = strings.Trim(result[:80], ".-_")
	}
	if result == "" {
		return "image"
	}
	return result
}

// generatedImageMarkdown 将已保存的文件对象转换为受保护文件接口的 markdown 引用。
func generatedImageMarkdown(files []model.FileObject) string {
	blocks := make([]string, 0, len(files))
	for i, file := range files {
		alt := "Generated image"
		if len(files) > 1 {
			alt = fmt.Sprintf("Generated image %d", i+1)
		}
		blocks = append(blocks, fmt.Sprintf("![%s](/api/v1/files/%s/content)", alt, file.FileID))
	}
	return strings.Join(blocks, "\n\n")
}

// attachmentsFromFiles 生成消息附件快照，供流式完成事件立即返回给前端。
func attachmentsFromFiles(files []model.FileObject) []AttachmentInput {
	items := make([]AttachmentInput, 0, len(files))
	for _, file := range files {
		items = append(items, AttachmentInput{
			FileObjID:        file.ID,
			FileID:           file.FileID,
			Kind:             "image",
			FileName:         file.FileName,
			MimeType:         file.MimeType,
			DetectedMIME:     file.DetectedMIME,
			FileCategory:     file.FileCategory,
			FileSize:         file.SizeBytes,
			SHA256:           file.SHA256,
			StoragePath:      file.StoragePath,
			ProcessingStatus: file.ProcessingStatus,
			ProcessingReady:  file.ProcessingReady,
		})
	}
	return items
}
